execfile('augmentation.py')
execfile('loaddata_aug.py')

from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense
from keras.models import load_model
from keras import initializers
from keras.layers import Conv2D,MaxPooling2D,Flatten, Dropout
from keras.layers.normalization import BatchNormalization
from keras import backend as K
from keras import optimizers

K.set_image_dim_ordering('th')

# creating the randomly augmented data without samplepairing
(inputs, targets_train) = augmented_input_stream(df)
(input_test, targets_test) = cropped_test(df_test)


#one hot encoding for the data
encoder = LabelEncoder()
encoder.fit(targets_train)
encoded_Y = encoder.transform(targets_train)
dummy_y = np_utils.to_categorical(encoded_Y)
encodermapping = list(encoder.classes_)

encoded_Ytest = encoder.transform(targets_test)
ytest = np_utils.to_categorical(encoded_Ytest)

# CNN architecture
modelfinal_aug = Sequential()
modelfinal_aug.add(BatchNormalization(input_shape=(3,28,28)))
modelfinal_aug.add(Conv2D(64, (3, 3),activation='relu'))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Conv2D(96, (3, 3),activation='relu'))
modelfinal_aug.add(MaxPooling2D(pool_size=(2,2)))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Conv2D(96, (3, 3),activation='relu'))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Conv2D(128, (3, 3),activation='relu'))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Conv2D(192, (3, 3),activation='relu'))
modelfinal_aug.add(MaxPooling2D(pool_size=(2,2)))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Dropout(0.4))
modelfinal_aug.add(Flatten())
modelfinal_aug.add(Dense(512, activation='relu'))
modelfinal_aug.add(Dropout(0.3))
modelfinal_aug.add(Dense(10, activation='softmax'))

modelfinal_aug.compile(loss = 'categorical_crossentropy', optimizer = 'adam', metrics = ['accuracy'])


#training the data on newly augmented data (without samplepairing) for each epoch
noofepochs = 500
storing = []
for counter in range(1,noofepochs):
    history= modelfinal_aug.fit(inputs, dummy_y, epochs=1, verbose = True, validation_data=(input_test, ytest))
    storing.append(history.history)
    (inputs, targets_train) = augmented_input_stream(df)
    encoded_Y = encoder.transform(targets_train)
    dummy_y = np_utils.to_categorical(encoded_Y)



modelfinal_aug.save('modelfinal_aug_2_200epochs')

predicttest = modelfinal_aug.predict(input_test)

import sklearn
temp = []
for count in predicttest:
    temp.append(encodermapping[(np.argmax(count))])
print(100*sklearn.metrics.accuracy_score(targets_test,temp))

#storing performance results.
import pickle
pickle_out = open("history_aug_2.pickle", "wb")
pickle.dump(storing, pickle_out)
pickle_out.close()
