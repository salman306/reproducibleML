# the model obtained from convnn_sampe.py i.e. the model trained on the sample paired dataframe
# is finetuned seperately

execfile('augmentation.py')
execfile('loaddata_aug.py')

from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense
from keras.models import load_model
from keras import initializers
from keras.layers import Conv2D,MaxPooling2D,Flatten, Dropout
from keras.layers.normalization import BatchNormalization
from keras import backend as K
from keras import optimizers

K.set_image_dim_ordering('th')

(inputs, targets_train) = augmented_input_stream(df)
(input_test, targets_test) = cropped_test(df_test)


encoder = LabelEncoder()
encoder.fit(targets_train)
encoded_Y = encoder.transform(targets_train)
dummy_y = np_utils.to_categorical(encoded_Y)
encodermapping = list(encoder.classes_)

encoded_Ytest = encoder.transform(targets_test)
ytest = np_utils.to_categorical(encoded_Ytest)

modelfinal_aug = load_model('modelfinal_samp')

noofepochs = 30
storing = []
for counter in range(1,noofepochs):
    history= modelfinal_aug.fit(inputs, dummy_y, epochs=1, verbose = True, validation_data=(input_test, ytest))
    storing.append(history.history)
    (inputs, targets_train) = augmented_input_stream(df)
    encoded_Y = encoder.transform(targets_train)
    dummy_y = np_utils.to_categorical(encoded_Y)



modelfinal_aug.save('model_samp_finetuned')

predicttest = modelfinal_aug.predict(input_test)

import sklearn
temp = []
for count in predicttest:
    temp.append(encodermapping[(np.argmax(count))])
print(100*sklearn.metrics.accuracy_score(targets_test,temp))

import pickle
pickle_out = open("finetuning.pickle", "wb")
pickle.dump(storing, pickle_out)
pickle_out.close()
