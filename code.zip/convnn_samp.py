# training another CNN using sample paired data this time

execfile('augmentation_2.py')
execfile('loaddata_aug.py')

(inputs, targets_train) = augmented_input_stream(df.iloc[0:100,:])
(sampinputs, samptargets) = sample_pair(inputs, targets_train)

from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.preprocessing import LabelEncoder
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense
from keras.models import load_model
from keras import initializers
from keras.layers import Conv2D,MaxPooling2D,Flatten, Dropout
from keras.layers.normalization import BatchNormalization
from keras import backend as K
from keras import optimizers

K.set_image_dim_ordering('th')

(inputs, targets_train) = augmented_input_stream(df)
(input_test, targets_test) = cropped_test(df_test)


encoder = LabelEncoder()
encoder.fit(targets_train)
encoded_Y = encoder.transform(targets_train)
dummy_y = np_utils.to_categorical(encoded_Y)
encodermapping = list(encoder.classes_)

encoded_Ytest = encoder.transform(targets_test)
ytest = np_utils.to_categorical(encoded_Ytest)


modelfinal_aug = Sequential()
modelfinal_aug.add(BatchNormalization(input_shape=(3,28,28)))
modelfinal_aug.add(Conv2D(64, (3, 3),activation='relu'))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Conv2D(96, (3, 3),activation='relu'))
modelfinal_aug.add(MaxPooling2D(pool_size=(2,2)))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Conv2D(96, (3, 3),activation='relu'))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Conv2D(128, (3, 3),activation='relu'))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Conv2D(192, (3, 3),activation='relu'))
modelfinal_aug.add(MaxPooling2D(pool_size=(2,2)))
modelfinal_aug.add(BatchNormalization())
modelfinal_aug.add(Dropout(0.4))
modelfinal_aug.add(Flatten())
modelfinal_aug.add(Dense(512, activation='relu'))
modelfinal_aug.add(Dropout(0.3))
modelfinal_aug.add(Dense(10, activation='softmax'))

modelfinal_aug.compile(loss = 'categorical_crossentropy', optimizer = 'adam', metrics = ['accuracy'])

noofepochs = 50
secondaryepoch = 150
looped = secondaryepoch/10
storing = []

#training it initially on the basic augmented data for 48 epochs
#new augmentations are generated in each epoch
for counter in range(0,48):
    print("counter1 ", counter)
    history= modelfinal_aug.fit(inputs, dummy_y, epochs=1, verbose = True, validation_data=(input_test, ytest))
    storing.append(history.history)
    (inputs, targets_train) = augmented_input_stream(df)
    encoded_Y = encoder.transform(targets_train)
    dummy_y = np_utils.to_categorical(encoded_Y)


#training on the the sample paired data.
#new samplepaired data is generated in each epoch
for counter in range(0,looped):
    for counter2 in range(1,3):
        (inputs, targets_train) = augmented_input_stream(df)
        encoded_Y = encoder.transform(targets_train)
        dummy_y = np_utils.to_categorical(encoded_Y)
        history= modelfinal_aug.fit(inputs, dummy_y, epochs=1, verbose = True, validation_data=(input_test, ytest))
        storing.append(history.history)
    for counter3 in range(1,9):
        (sampinputs, samptargets) = sample_pair(inputs, targets_train)
        encoded_targets = encoder.transform(samptargets)
        dummy_targets = np_utils.to_categorical(encoded_Y)
        history= modelfinal_aug.fit(sampinputs, dummy_targets, epochs=1, verbose = True, validation_data=(input_test, ytest))
        storing.append(history.history)


modelfinal_aug.save('modelfinal_test')

predicttest = modelfinal_aug.predict(input_test)

import sklearn
temp = []
for count in predicttest:
    temp.append(encodermapping[(np.argmax(count))])
print(100*sklearn.metrics.accuracy_score(targets_test,temp))

import pickle
pickle_out = open("history_test.pickle", "wb")
pickle.dump(storing, pickle_out)
pickle_out.close()
