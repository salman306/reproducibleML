seed = 1

import numpy as np
import pandas as pd

#https://openreview.net/forum?id=SJn0sLgRb

def unpickle(file):
    import cPickle
    with open(file, 'rb') as fo:
        dict = cPickle.load(fo)
    return dict

# unpickling the data. Instructions were on the CIFAR-10 webpage

batch1 = unpickle("data_batch_1")
batch2 = unpickle("data_batch_2")
batch3 = unpickle("data_batch_3")
batch4 = unpickle("data_batch_4")
batch5 = unpickle("data_batch_5")
batchtest = unpickle("test_batch")

#forming the data into a dataframe
df = pd.DataFrame(batch1['data'])
df = df.append(pd.DataFrame(batch2['data']))
df = df.append(pd.DataFrame(batch3['data']))
df = df.append(pd.DataFrame(batch4['data']))
df = df.append(pd.DataFrame(batch5['data']))

df_test = pd.DataFrame(batchtest['data'])

#adding labels to the DataFrame
targets1 = batch1['labels']
targets2 = batch2['labels']
targets3 = batch3['labels']
targets4 = batch4['labels']
targets5 = batch5['labels']
targettest = batchtest['labels']


target = targets1+targets2+targets3+targets4+targets5
df['targets'] = target
df_test['targets'] = targettest

#basic augmentation methods consolidated into one function
def augmented_input_stream(dataframe):
    auginput_train = []
    augout_train = []
    for counter in range(1, dataframe.shape[0]):
        temp = list(dataframe.iloc[counter, 0:3072])
        temp = reformat(temp, 32, 32)
        temp = rand_crop(temp, 28)
        temp = rand_horizontal_flip(temp, 0.5)
        auginput_train.append(temp)
        augout_train.append(dataframe.iloc[counter, 3072])
    return (np.array(auginput_train), np.array(augout_train))

#the test data is cropped differently with a 28 by 28 chunk from the middle, as opposed to randomly for training data
def cropped_test(testdf):
    auginput_test = []
    augout_test = []
    for counter in range(1, testdf.shape[0]):
        temp = list(testdf.iloc[counter, 0:3072])
        temp = reformat(temp, 32, 32)
        temp = center_crop(temp, 28)
        auginput_test.append(temp)
        augout_test.append(testdf.iloc[counter,3072])
    return (np.array(auginput_test), np.array(augout_test))
